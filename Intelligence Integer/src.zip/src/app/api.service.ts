import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Employee } from './Employee';
import { Admin } from './login/admin';


const remoteUrl = "http://localhost:1111";
@Injectable({
  providedIn: 'root'
})
export class ApiService {

  constructor(private httpClient: HttpClient) { }

  registerEmployee(employee:Employee){
    return this.httpClient.post(remoteUrl+'/employee',employee);

  }
  employeeLogin(employee:Employee){
    return this.httpClient.post(remoteUrl+'/employee/login',employee);
  }

  registerAdmin(admin: Admin){
    return this.httpClient.post(remoteUrl+'/admin',admin);
  }
}
