export class Admin{
    adminName:string;
    emailId:string;
    password:string;
}