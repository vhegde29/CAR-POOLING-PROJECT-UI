export class Car{
    carId:number;
     carNo:string;
    carName:string;
 carColour:string;
 
}