export class User{
    uId:number;
     password:string;
    fname:string;
 lname:string;
 email:string;
     phoneNo:string;
    dob:Date;
}