import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-createfrequenttrip',
  templateUrl: './createfrequenttrip.component.html',
  styleUrls: ['./createfrequenttrip.component.css']
})
export class CreatefrequenttripComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
