import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-updateacar',
  templateUrl: './updateacar.component.html',
  styleUrls: ['./updateacar.component.css']
})
export class UpdateacarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
