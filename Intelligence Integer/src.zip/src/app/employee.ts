export class Employee{
    employeeID:number;
    employeeName:string;
    emailId:string;
    department:string;
    password:string;
}