import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-searchfrequenttrip',
  templateUrl: './searchfrequenttrip.component.html',
  styleUrls: ['./searchfrequenttrip.component.css']
})
export class SearchfrequenttripComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
