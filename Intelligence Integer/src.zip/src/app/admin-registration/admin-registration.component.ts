import { Component, OnInit } from '@angular/core';
import { Admin } from '../login/admin';
import { ApiService } from '../api.service';

@Component({
  selector: 'app-admin-registration',
  templateUrl: './admin-registration.component.html',
  styleUrls: ['./admin-registration.component.css']
})
export class AdminRegistrationComponent implements OnInit {
  admin: Admin;
  constructor(private apiService:ApiService) { }

  ngOnInit() {
  this.admin = new Admin;
  }
  submitForm(){
    this.apiService.registerAdmin(this.admin).subscribe(data => console.log(data));
  }
}

