import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-searchregulartrip',
  templateUrl: './searchregulartrip.component.html',
  styleUrls: ['./searchregulartrip.component.css']
})
export class SearchregulartripComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
