import { Component, OnInit } from '@angular/core';
import { ApiService } from '../api.service';
import { Employee } from '../Employee';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  employee: Employee;
 
  constructor(private apiService : ApiService) { }

  ngOnInit() {
    this.employee = new Employee;
  }

    submitForm(){
      
      this.apiService.employeeLogin(this.employee).subscribe(data => console.log(data));
    }
}
