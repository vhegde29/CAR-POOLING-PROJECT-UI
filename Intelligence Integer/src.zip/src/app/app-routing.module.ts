import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { AdminComponent } from './admin/admin.component';
import { AboutComponent } from './about/about.component';
import { AdminRegistrationComponent } from './admin-registration/admin-registration.component';
import { EmployeeRegistrationComponent } from './employee-registration/employee-registration.component';
import { EmployeeLoginComponent } from './employee-login/employee-login.component';
import { AdminLoginComponent } from './admin-login/admin-login.component';

const routes: Routes = [
  {path:"login", component:LoginComponent},
  {path:"adminlogin", component:AdminLoginComponent},
 
  {path:"register", component:RegisterComponent},
  {path:"adminregister", component:AdminRegistrationComponent},
  {path:"employeeregister", component:EmployeeRegistrationComponent},
  {path:"admin", component:AdminComponent},
  {path:"about", component:AboutComponent},

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
